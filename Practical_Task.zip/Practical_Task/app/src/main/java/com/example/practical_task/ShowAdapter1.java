package com.example.practical_task;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ShowAdapter1 extends RecyclerView.Adapter<ShowAdapter1.ViewHolder> {
    private Context context;
    private ArrayList<Data_Response> responses;
    private List<Data_Response> exampleListFull;

    public ShowAdapter1(Context context, ArrayList<Data_Response> data_response) {
        this.context = context;
        this.responses = data_response;
    }

    @NonNull
    @Override
    public ShowAdapter1.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_list, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ShowAdapter1.ViewHolder holder, final int position) {
        //holder.textView_Serial_Number.setText(responses.get(position).getId());
        holder.textView_Serial_Number.setText(String.valueOf(position + 1));
        holder.textView_City_Name.setText(responses.get(position).getCity());
        holder.textView_First_Name.setText(responses.get(position).getFirst_name());
        holder.textView_Second_Name.setText(responses.get(position).getLast_name());
    }

    @Override
    public int getItemCount() {
        return responses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textView_Serial_Number, textView_City_Name, textView_First_Name, textView_Second_Name;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView_Serial_Number = itemView.findViewById(R.id.textView_Serial_Number);
            textView_City_Name = itemView.findViewById(R.id.textView_City_Name);
            textView_First_Name = itemView.findViewById(R.id.textView_First_Name);
            textView_Second_Name = itemView.findViewById(R.id.textView_Last_Name);
        }
    }

    /*public void filter1(String City) {
        responses.clear();
        for(Data_Response nr:tempArray){
            switch (City) {
                case "1":
                    if(nr.getCity().trim().toUpperCase().equals(City)){
                        responses.add(nr);

                    }
                    break;

                default:
                    responses.addAll(tempArray);

            }
        }
        notifyDataSetChanged();
    }*/
}
