package com.example.practical_task;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class Los_Angeles_Fragment extends Fragment {
    RecyclerView show_recyclerView;
    private LinearLayoutManager layoutManager;
    int pos;
    ShowAdapter1 showAdapter;


    public Los_Angeles_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_los__angeles_, container, false);
        show_recyclerView = view.findViewById(R.id.show_recyclerView3);

        layoutManager = new LinearLayoutManager(getContext() , LinearLayoutManager.VERTICAL , false);
        show_recyclerView.setLayoutManager(layoutManager);
        show_recyclerView.setHasFixedSize(true);

        // For Scrolling The Recyclerview Smoothly
        RecyclerView.SmoothScroller smoothScroller = new LinearSmoothScroller(getContext()) {
            @Override
            protected int getVerticalSnapPreference() {
                return LinearSmoothScroller.SNAP_TO_START;
            }
        };
        smoothScroller.setTargetPosition(pos);

        ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<ArrayList<Data_Response>> newCall = apiInterface.getData();
        newCall.enqueue(new Callback<ArrayList<Data_Response>>() {
            @Override
            public void onResponse(Call<ArrayList<Data_Response>> call, Response<ArrayList<Data_Response>> response) {
                try {
                    ArrayList<Data_Response> data_response = response.body();
                   /* showAdapter = new ShowAdapter1(getContext(), data_response);
                    show_recyclerView.getLayoutManager().scrollToPosition(pos);
                    show_recyclerView.setAdapter(showAdapter);*/
                    ArrayList<Data_Response> arr = new ArrayList<>();
                    for (Data_Response s : data_response) {
                        if (s.getCity().equals("Los Angeles")) {
                            arr.add(s);
                            Log.d("vvdv", String.valueOf(arr));
                            showAdapter = new ShowAdapter1(getContext(), arr);
                            show_recyclerView.getLayoutManager().scrollToPosition(pos);
                            show_recyclerView.setAdapter(showAdapter);
                        }

                    }
                }
                catch (NullPointerException e)
                {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Data_Response>> call, Throwable t) {

            }
        });
        return view;
    }

}
