package com.example.practical_task;

import com.google.gson.Gson;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient
{
    // It Is For Development Api(BASE_URL)
    public static final String BASE_URL = "https://api.npoint.io/";
    public static Retrofit retrofit = null;


    public static Retrofit getApiClient() {
        System.out.print("BASE_URL:"+BASE_URL);
        // setting custom timeouts
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(50, TimeUnit.SECONDS)
                .writeTimeout(50, TimeUnit.SECONDS)
                .readTimeout(50,TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();
        if (retrofit == null) {

            retrofit = new Retrofit.Builder().baseUrl(BASE_URL).client(client).
                    addConverterFactory(GsonConverterFactory.create(new Gson())).build();

        }
        return retrofit;
    }

}

