package com.example.practical_task;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface
{

    @GET("81ada0361bbd877efb9e")
    Call<ArrayList<Data_Response>> getData();

}
